export interface userdtls
{
    id?:number
    username?:string
    password?:string
    firstname?:string
    lastname?:string
    contactnumber?:number
    regcode?:string
    active?:string
    resetpassword?:string
    regdatetime?:Date  
}