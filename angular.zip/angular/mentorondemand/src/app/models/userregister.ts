export interface userregister
{
    username?:string
    password?:string
    firstname?:string
    lastname?:string
    contactnumber?:number
    regdatetime?:Date  
}