export interface admin
{
    aId?:number
    aUsername?:string
    aPassword?:string
} 