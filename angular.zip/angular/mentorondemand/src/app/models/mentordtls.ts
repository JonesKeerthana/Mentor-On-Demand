export interface mentordtls
{
    mId?:number
    mName?:string
    mUsername?:string
    mPassword?:string
    mLinkedinurl?:string
    mRegdattime?:Date
    mRegcode?:number
    mYearsofexperience?:number
    mActive?:string
    
}