export interface mentorregister
{
   
    mName?:string
    mUsername?:string
    mPassword?:string
    mLinkedinurl?:string
   mYearsofexperience?:number
   
    
}